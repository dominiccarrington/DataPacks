# Death Swap
**Originally created by [SethBling](https://www.youtube.com/watch?v=r5rEaHPt6mw)**

This games puts two people together to try and kill the other. Simple enough, right? However the players are teleported too far away to kill using ordinary means and every 20-40 seconds they swap locations.