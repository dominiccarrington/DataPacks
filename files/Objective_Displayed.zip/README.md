# Objective Displayed
Cycles the objective displayed under the nametag of all players every 30 seconds.

Currently setup to track:
- Withers Killed
- Ender Dragons Killed
- Players Killed