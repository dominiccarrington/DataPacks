# SpeedRunner VS Hunter
**Datapack created by: [3boood_pro](https://www.planetminecraft.com/data-pack/speedrunner-vs-hunters/) | Idea created by: [Dream](https://www.youtube.com/user/DreamTraps)**

One person tries to speedrun Minecraft, meanwhile any number of people are tracking them down and kill them before they complete that task. Hunters get a compass that always points towards the SpeedRunner and works in any dimension.

## Known Issues
- The compass will only update when in the players hotbar and will be flicking when held (Limitations of Vanilla unfortunally)
- Due to the way the compass is updated, shulker boxes will not drop themselves and will only drop there contents (Limitations of Vanilla)
    - This probably has a workaround, however due to the nature of this gamemode, I will not be persueing it.